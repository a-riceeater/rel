/*
    The default application module
*/